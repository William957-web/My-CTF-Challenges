Challenge name: FaaS
Challenge description: Welcome to Find as a Service
Author name: Whale120 (whale.120)
FLAG: QnQSec{big_thanks_2_🍊_4876three}
