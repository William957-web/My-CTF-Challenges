Challenge name: Date Logger!
Challenge description: I made a date logger as a simple diary ...
Author name: Whale120 (whale.120)
FLAG: QnQSec{F_u_L1NuX_:cry:}
