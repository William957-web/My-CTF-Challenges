Challenge name: Republic of Geese
Challenge description: Honk! Quack? Crack! Welcome to The Republic of Geese
Author name: Whale120 (whale.120)
FLAG: QnQSec{g33s3_d0nt_0verth1nk_th3y_0v3r_fl4p_0a9bec6f}
