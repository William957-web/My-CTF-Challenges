Challenge name: 🐿️📞
Challenge description: I hate Crypto Oracles ... but I would like to make a call to squirrel (squirrel-cle :>)!
Author name: Whale120 (whale.120)
FLAG: QnQSec{i_really_really_really_really_really_really_really_like_u_:)_🎹🎼🐋}
