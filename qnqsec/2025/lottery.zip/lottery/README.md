Challenge name: Cat's Lottery
Challenge description:
We all know that cat, catcat, catcatcat ... cats love to eat subway burgers cause this is their staple food  
But today our friend, catcat, don't have enough money to buy as much buggers as she want to eat like 100000 days in a row and very disappointment about that  
Because of this, she decided to hack our QnQ Lottery system, not only winning the lottery but also to still our secret flag ...  
and sell it :>  
Author name: Whale120 (whale.120) and qawse (lo4pca)
FLAG: QnQSec{well...the_cat_cat_can_now_buy_subway_burgers_via_winning_the_lottery_now_!}
